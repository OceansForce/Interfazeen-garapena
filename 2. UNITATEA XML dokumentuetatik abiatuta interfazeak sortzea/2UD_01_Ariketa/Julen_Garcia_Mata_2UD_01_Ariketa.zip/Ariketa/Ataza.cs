﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ariketa
{
    public class Ataza
    {
        public string Titulua { get; set; }
        public string Lehentasuna { get; set; }
        public string Azken_eguna { get; set; }
        public bool Egina { get; set; }

    }
}
